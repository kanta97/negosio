// collapse Nav Link
$(".nav-link ").on("click", function () {
  $(".navbar-collapse").collapse("hide");
});
